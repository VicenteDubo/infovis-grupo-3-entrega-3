Protobject.setProduction(true)
Protobject.initialize(
	[
		{ 
			name: "ArUco",
			page: "order_salud.html",
			debug: "local",
		},
		{ 
			name: "Salud",
			page: "index.html",
			main: true,
			debug: "master",
		}
	]);

