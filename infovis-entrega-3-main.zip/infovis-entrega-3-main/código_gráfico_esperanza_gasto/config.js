Protobject.setProduction(true)
Protobject.initialize(
	[
		{ 
			name: "ArUco",
			page: "order.html",
			debug: "local",
		},
		{ 
			name: "Lamp",
			page: "index.html",
			main: true,
			debug: "master",
		}
	]);

 
